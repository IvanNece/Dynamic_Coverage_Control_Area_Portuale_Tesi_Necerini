    # for t in range(duration):
    #     coverageIndices_t_stop = calculateCoverageIndices(tempTargetPositions, agentTrajectoriesV1[t], t, r, mp)
    #     totalCoverageIndex_t_stop = calculateTotalCoverageIndex(coverageIndices_t_stop, t, lowerboundIndex)
    #     totalCoverageIndex_values_stoppedTargets.append(totalCoverageIndex_t_stop)