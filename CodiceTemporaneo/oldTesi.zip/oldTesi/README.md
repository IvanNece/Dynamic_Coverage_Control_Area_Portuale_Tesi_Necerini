# Dynamic_Coverage_Control_Area_Portuale_Tesi_Necerini
Progetto di tesi, laurea triennale in ingegneria informatica UNIFI
