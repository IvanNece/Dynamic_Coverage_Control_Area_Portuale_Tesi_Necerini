    print("\n\nINDICE DI COPERTURA COMPLESSIVO ALL'ISTANTE t=0 e t=finale, CON TARGET FERMI: \n:")
    print(totalCoverageIndex_values_stoppedTargets[0])
    print(totalCoverageIndex_values_stoppedTargets[199])